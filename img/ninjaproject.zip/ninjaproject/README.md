# ninjaproject

Font Used = 'Raleway' Link  = "https://fonts.googleapis.com/css?family=Raleway" 
Font Used = 'Roboto' Link = "https://font.google.com/css/css?family=Roboto"
Font Size = 62.5% (10px)

Naming convention for classes : base-class base-class__component<br>
  eg. btn btn__about-us
  eg. header header__heading

Installing dependencies : 
  1. Install node.js
  2. run "npm install" from the main directory. 
     Node will automatically scan the package.json file and install the dependencies.

Thanks for visiting.
